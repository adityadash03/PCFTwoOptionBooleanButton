var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./TwoOptionBooleanButton/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./TwoOptionBooleanButton/index.ts":
/*!*****************************************!*\
  !*** ./TwoOptionBooleanButton/index.ts ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.TwoOptionBooleanButton = void 0;\n\nvar TwoOptionBooleanButton =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function TwoOptionBooleanButton() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  TwoOptionBooleanButton.prototype.init = function (context, notifyOutputChanged, state, container) {\n    var _a, _b; // Initialize Component variables\n\n\n    this.theContainer = container;\n    this.theContext = context;\n    this.theNotifyChanged = notifyOutputChanged;\n    context.mode.trackContainerResize(false); // Get all options\n\n    this.optionSetArray = (_a = context.parameters.TwoOptionSetAttribute.attributes) === null || _a === void 0 ? void 0 : _a.Options; // Add code to update control view\n\n    this._defaultValue = (_b = context.parameters.TwoOptionSetAttribute.attributes) === null || _b === void 0 ? void 0 : _b.DefaultValue; // Current selected value\n\n    var currentInputData = context.parameters.TwoOptionSetAttribute.raw;\n\n    if (currentInputData != null) {\n      this._outputValue = currentInputData;\n    } else {\n      if (this._defaultValue != null) {\n        this._outputValue = this._defaultValue;\n      }\n    }\n\n    this._isControlReadOnly = context.mode.isControlDisabled; // UI\n    // Main Container\n\n    this.eleMainContainer = document.createElement(\"div\");\n    this.eleMainContainer.id = \"mybtn\";\n    this.eleMainContainer.className = \"btn-group\"; // Create OptionSet Buttons\n\n    if (this.optionSetArray) {\n      var width = 100 / this.optionSetArray.length;\n\n      for (var i = 0; i < this.optionSetArray.length; i++) {\n        // Button\n        var eleButton = void 0;\n        eleButton = document.createElement(\"button\");\n        eleButton.innerHTML = this.optionSetArray[i].Label;\n        eleButton.id = this.optionSetArray[i].Value.toString();\n        eleButton.style.width = width.toString() + \"%\";\n        eleButton.style.background = \"#6f6f6f\";\n        eleButton.disabled = context.mode.isControlDisabled;\n\n        if (context.mode.isControlDisabled == false) {\n          eleButton.addEventListener(\"click\", this.onButtonClick.bind(this));\n        }\n\n        this.eleMainContainer.appendChild(eleButton);\n      }\n    }\n\n    container.appendChild(this.eleMainContainer);\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  TwoOptionBooleanButton.prototype.updateView = function (context) {\n    if (this.eleMainContainer.children.length > 0) {\n      var _loop_1 = function _loop_1() {\n        var elementButton = this_1.eleMainContainer.children[i];\n\n        if (this_1._outputValue === true) {\n          if (elementButton.id === \"1\") {\n            if (this_1.optionSetArray) {\n              result = this_1.optionSetArray.filter(function (obj) {\n                return obj.Value === parseInt(elementButton.id);\n              });\n              elementButton.style.background = result[0].Color;\n            }\n          }\n\n          if (elementButton.id === \"0\") {\n            elementButton.style.background = \"#6f6f6f\";\n          }\n        } else if (this_1._outputValue === false) {\n          if (elementButton.id === \"0\") {\n            if (this_1.optionSetArray) {\n              result = this_1.optionSetArray.filter(function (obj) {\n                return obj.Value === parseInt(elementButton.id);\n              });\n              elementButton.style.background = result[0].Color;\n            }\n          }\n\n          if (elementButton.id === \"1\") {\n            elementButton.style.background = \"#6f6f6f\";\n          }\n        }\n      };\n\n      var this_1 = this,\n          result,\n          result;\n\n      for (var i = 0; i < this.eleMainContainer.children.length; i++) {\n        _loop_1();\n      }\n    }\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  TwoOptionBooleanButton.prototype.getOutputs = function () {\n    return {\n      TwoOptionSetAttribute: this._outputValue\n    };\n  };\n\n  TwoOptionBooleanButton.prototype.onButtonClick = function (event) {\n    // Selected button details\n    var selectedElement = event.target;\n    if (selectedElement.id === \"0\") this._outputValue = false;else if (selectedElement.id === \"1\") this._outputValue = true; // if (selectedElement) this._outputValue = parseInt(selectedElement.id);\n\n    this.theNotifyChanged();\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  TwoOptionBooleanButton.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  return TwoOptionBooleanButton;\n}();\n\nexports.TwoOptionBooleanButton = TwoOptionBooleanButton;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./TwoOptionBooleanButton/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('TwoOptionBooleanButton.TwoOptionBooleanButton', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.TwoOptionBooleanButton);
} else {
	var TwoOptionBooleanButton = TwoOptionBooleanButton || {};
	TwoOptionBooleanButton.TwoOptionBooleanButton = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.TwoOptionBooleanButton;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}